//
//  ASObject.m
//  ArraysTest
//
//  Created by Anton Gorlov on 01.09.15.
//  Copyright (c) 2015 Anton Gorlov. All rights reserved.
//

#import "ASObject.h"

@implementation ASObject
-(void) action {
    NSLog(@"%@ ACTION!!", self.name);
    
    
}
@end
