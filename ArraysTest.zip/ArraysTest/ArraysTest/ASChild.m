//
//  ASChild.m
//  ArraysTest
//
//  Created by Anton Gorlov on 02.09.15.
//  Copyright (c) 2015 Anton Gorlov. All rights reserved.
//

#import "ASChild.h"

@implementation ASChild

-(void) action {
    NSLog(@"%@ Child Action!", self.name);
}
@end
